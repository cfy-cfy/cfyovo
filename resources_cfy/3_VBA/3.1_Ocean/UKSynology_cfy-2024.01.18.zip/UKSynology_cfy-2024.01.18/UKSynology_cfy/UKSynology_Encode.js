utfencode=function(b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var e = 0; e < b.length; e++) {
            var d = b.charCodeAt(e);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
}

bin2hex=function(d) {
    d = utfencode(d);
    var c, e = 0, b = [];
    d += "";
    e = d.length;
    for (c = 0; c < e; c++) {
        b[c] = d.charCodeAt(c).toString(16).replace(/^([\da-f])$/, "0$1")
    }
    return b.join("")
}

